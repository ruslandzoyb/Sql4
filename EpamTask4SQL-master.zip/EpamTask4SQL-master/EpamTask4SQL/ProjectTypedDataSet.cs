﻿namespace EpamTask4SQL
{


    partial class ProjectTypedDataSet
    {
    }
}

namespace EpamTask4SQL.ProjectTypedDataSetTableAdapters {
    
    
    public partial class EmployeeTableAdapter {
    }
}
