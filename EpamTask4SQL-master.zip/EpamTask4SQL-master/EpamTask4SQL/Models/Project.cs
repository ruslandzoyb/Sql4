﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EpamTask4SQL
{
    class Project
    {
        public int ID;
        public string Name;
        public DateTime CreationDate;
        public bool Finished;
        public DateTime FinishDate;
        public string Description;
    }
}
