﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EpamTask4SQL
{
    class Employee
    {
        public int ID;
        public string Name;
        public string Surname;
        public DateTime BirthDay;
    }
}
