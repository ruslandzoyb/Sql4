# EpamTask4SQL
 Task4 SQL

View ConnectionAdapter.cs to see all the querries